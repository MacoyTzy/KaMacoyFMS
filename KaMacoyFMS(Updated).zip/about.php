<?php
include('./timeout.php');
echo '<html>';
echo '<body>';
echo '';
echo '<p>';
echo 'Crafted and Compiled by Ka Macoy © 2021 All Rights Reserved';
echo '</p>';
echo '';
echo '</body>';
echo '</html>';
echo '';
?>

<audio controls autoplay controlsList="nodownload">
    <source src="assets/mp3/yourmyheart.mp3" type="audio/mpeg">
Error 404 : Your browser does not support the audio element.
</audio>