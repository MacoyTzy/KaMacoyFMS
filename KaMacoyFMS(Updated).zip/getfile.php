<?php //this code shows the full directory in a folder -Marisol
    $path    = './assets/uploads';
    $files = scandir($path);
    $files = array_diff(scandir($path), array('.', '..'));
    foreach($files as $file){
    echo "<a href='$file'>$file</a>";
    }
?>