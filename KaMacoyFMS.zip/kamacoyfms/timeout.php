<?php
$t=time();
if (isset($_SESSION['logged']) && ($t - $_SESSION['logged'] > 1800)) { //1800 secs is 30 minutes (shoutout to google for this) -Macoy
    session_destroy(); //ends the session -Macoy
    session_unset(); //resets the current session usage to 0 -Marisol
    header("location:login.php"); //redirects to login page after logout -Macoy
    //header("Refresh:900"); //refresh interval (no need, because i dont know! it's not working! *lmao*) - Macoy
}else {
   $_SESSION['logged'] = time(); //defines logged time usage -Marisol
} 
?> 
<script>
    window.setInterval('refresh()', 1800000); //Call a function every 1800000 milliseconds (OR 30 mins). - Marisol
    function refresh() {    //Refresh or reload page. -Macoy
        window .location.reload();
    }
</script>
